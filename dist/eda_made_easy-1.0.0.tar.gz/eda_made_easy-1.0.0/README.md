# easyEDA
It is used to automate some of the EDA stuff like missing value impuation, outlier removal and scaling the data.
The class will take dataset in pandas dataframe data type and funtions can be called accordingly.

##Installation
```pip install easyEDA```

How to use it?
Open terminal and type easyEDA and put dataset inside it.

##License
© 2021 Raghav Bakshi

This repository is licensed under the MIT license. See LICENSE for details. 